from flask import Flask, request, jsonify, render_template
import joblib
import boto3
import io
import logging
import numpy as np
from your_custom_module import Environment

app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Define S3 bucket and model file details
S3_BUCKET_NAME = 'mybuc143'
MODEL_FILE_KEY = 'models/reinforcement_model.pkl'

def load_model_from_s3(bucket_name, model_file_key):
    s3_client = boto3.client('s3')
    try:
        response = s3_client.get_object(Bucket=bucket_name, Key=model_file_key)
        model_file = io.BytesIO(response['Body'].read())
        model = joblib.load(model_file)
        return model
    except Exception as e:
        logging.error(f"Error loading model from S3: {e}")
        raise

# Load the trained model from S3
try:
    model_data = load_model_from_s3(S3_BUCKET_NAME, MODEL_FILE_KEY)
    q_table = model_data['q_table']
    logging.info("Model loaded successfully.")
except Exception as e:
    q_table = None
    logging.error(f"Failed to load model: {e}")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if q_table is None:
        return jsonify({'error': 'Model not loaded'}), 500
    
    try:
        data = request.get_json()
        state = int(data.get('state'))
        
        # Make the prediction
        predicted_action = np.argmax(q_table[state])  
        return jsonify({'predicted_action': int(predicted_action)})
    except Exception as e:
        logging.error(f"Prediction error: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
