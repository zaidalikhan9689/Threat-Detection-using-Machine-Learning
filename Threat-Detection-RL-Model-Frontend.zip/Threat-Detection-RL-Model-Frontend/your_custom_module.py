# your_custom_module.py

import numpy as np

class Environment:
    def __init__(self, features, labels):
        self.features = features
        self.labels = labels
        self.current_state_idx = 0

    def reset(self):
        self.current_state_idx = 0
        return self.features[self.current_state_idx]

    def step(self, action):
        reward = 1 if action == self.labels[self.current_state_idx] else -1
        self.current_state_idx += 1
        if self.current_state_idx >= len(self.features):
            done = True
            next_state = None
        else:
            done = False
            next_state = self.features[self.current_state_idx]

        return next_state, reward, done
